package com.client;
import com.management.AllocationManagement;
import com.model.Allocation;
import com.model.Appointment;
import com.model.Doctor;
import com.model.InPatient;
import com.model.OutPatient;
import com.model.Payment;
import com.service.*;
import com.util.ApplicationUtil;

import java.util.Scanner;

public class UserInterface {
    
	public static void main(String args[]) {
	
		
	
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("              AAA HOSPITAL MANAGEMENT SYSTEM");
			
			int choice=0,patChoice;
			do {
				System.out.println("Enter your choice\n1.OUTPATIENT Manipulation\n2.INPATIENT Manipulation\n3.DOCTOR Manipulation\n4.APPOINTMENT Manipulation\n5.ALLOCATION Manipulation\n6.PAYMENT Manipulation");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
				
					do
					{
						System.out.println("1.ADD Outpatient Details\n2.UPDATE Outpatient Details\n3.DELETE Outpatient Details\n4.RETRIEVE Outpatient Details\n5.Main menu");
						
							patChoice=sc.nextInt();
						switch(patChoice)
						{
						case 1:
						{
							System.out.println("Enter the number of outpatient to be added");
							int n=sc.nextInt();
							String details[]=new String[n];
							System.out.println("Enter outptient details in the below format");
							System.out.println("PatientName:PhoneNo:Age:Gender:MedicalHistory:PrefferedSpecialist:MedicineFee:PatientType:RegistrationFees");
							for(int i=0;i<n;i++)
							{
								details[i]=sc.next();
								
							}
							OutPatientService out=new OutPatientService();
							boolean flag=out.addOutPatientList(details);
							if(flag)
							{
								System.out.println("Outpatient details added successfully");
							}
							break;							
					}
						case 2:
							int choice1=0;
							do {
								System.out.println("Enter the details to update details\n1.UPDATE phone number\n2.EXIT");
								choice1=sc.nextInt();
								switch(choice1)
								{
								case 1:
								{
									System.out.println("Enter the patient Id");
									String patientId=sc.next();
									System.out.println("Enter the phone number");
									long phoneNumber=sc.nextLong();
									OutPatientService out1=new OutPatientService();
									boolean b=out1.updateOutPatientPhoneNumber(patientId,phoneNumber);
									if(b)
									{
										System.out.println("Outpatient phone number updated successfully");
									}
									}
								}
							}while(choice1<2);
							break;
								case 3:
								{ 
									int choice2=0;
								
									do {
										System.out.println("Enter the details to delete\n1.Delete patient details\n2.EXIT");
										choice2=sc.nextInt();
									
										switch(choice2)
										{
										case 1:
										{
											
										
									System.out.println("Enter the patient Id");
									String patientId=sc.next();
									OutPatientService out2=new OutPatientService();
									boolean b1=out2.deleteOutPatientDetail(patientId);
									if(b1)
									{
										System.out.println(patientId+" is deleted successfully");
									}
										
								}
							}
								
								}while(choice2<2);
								} break;	
						case 4:
								System.out.println("Enter the patient Id");
							String patientId=sc.next();
							OutPatientService out3=new OutPatientService();
							
							System.out.println();
                          
							
							for(OutPatient o:out3.retrieveOutPatientDetail(patientId)) {
								System.out.println("patient id: "+o.getPatientId());
								System.out.println("patient Name: "+o.getPatientName());
								System.out.println("PhoneNumber: "+o.getPhoneNumber());
								System.out.println("Age: "+o.getAge());
								System.out.println("Gender: "+o.getGender());
								System.out.println("MedicalHistory: "+o.getMedicalHistory());
								System.out.println("PrefferedSpecialist: "+o.getPrefferedSpecialist());
								System.out.println("MedicineFee: "+o.getMedicineFee());
								
								
							}						

						}
					}while(patChoice<=4);break;
					

				case 2:
				
					do
					{
						System.out.println("1.ADD Inpatient Details\n2.UPDATE Inpatient Details\n3.DELETE Inpatient Details\n4.RETRIEVE Inpatient Details\n5.Main menu");
						
						patChoice=sc.nextInt();
						switch(patChoice)
						{
						case 1:
						{
							System.out.println("Enter the number of inpatient to be added");
							int n=sc.nextInt();
							String details1[]=new String[n];
							System.out.println("Enter inpatient details in the below format");
							System.out.println("PatientName:PhoneNo:Age:Gender:MedicalHistory:PrefferedSpecialist:MedicineFee:patientType:AdmissionFees:treatment:RoomType:WantFood");
							for(int i=0;i<n;i++)
							{
								details1[i]=sc.next();
								
							}
							InPatientService out=new InPatientService();
							boolean flag=out.addInPatientList(details1);
							if(flag)
							{
								System.out.println("Inpatient details added successfully");
							}
							break;							
					}
						case 2:
							int choice1=0;
							do {
								System.out.println("Enter the details to update details\n1.UPDATE phone number\n2.EXIT");
								choice1=sc.nextInt();
								switch(choice1)
								{
								case 1:
								{
									System.out.println("Enter the patient Id");
									String patientId=sc.next();
									System.out.println("Enter the phone number");
									long phoneNumber=sc.nextLong();
									InPatientService out1=new InPatientService();
									boolean b=out1.updateInPatientPhoneNumber(patientId,phoneNumber);
									if(b)
									{
										System.out.println("Inpatient phone number updated successfully");
									}
									}
								}
							}while(choice1<2);
							break;
								case 3:
								{ 
									int choice2=0;
								
									do {
										System.out.println("Enter the details to delete\n1.Delete patient details\n2.EXIT");
										choice2=sc.nextInt();
									
										switch(choice2)
										{
										case 1:
										{
											
										
									System.out.println("Enter the patient Id");
									String patientId=sc.next();
									InPatientService out2=new InPatientService();
									boolean b1=out2.deleteInPatientDetail(patientId);
									if(b1)
									{
										System.out.println(patientId+" is deleted successfully");
									}
										
								}
							}
								
								}while(choice2<2);
								} break;	
						case 4:
								System.out.println("Enter the patient Id");
							String patientId=sc.next();
							InPatientService out3=new InPatientService();
							
							System.out.println();
                          
							
							for(InPatient o:out3.retrieveInPatientDetail(patientId)) {
								System.out.println("patient id: "+o.getPatientId());
								System.out.println("patient Name: "+o.getPatientName());
								System.out.println("PhoneNumber: "+o.getPhoneNumber());
								System.out.println("Age: "+o.getAge());
								System.out.println("Gender: "+o.getGender());
								System.out.println("MedicalHistory: "+o.getMedicalHistory());
								System.out.println("PrefferedSpecialist: "+o.getPrefferedSpecialist());
								System.out.println("AdmissionFees: "+o.getAdmissionFees());
								System.out.println("Treatment: "+o.getTreatment());
								System.out.println("RoomType: "+o.getRoomType());
								System.out.println("WantFood: "+o.getWantFood());
								
								
								
							}						

						}
					}while(patChoice<=4);
					break;
					
					
				case 3:
					
					do
					{
						System.out.println("1.ADD Doctor Details\n2.UPDATE Doctor Details\n3.DELETE Doctor Details\n4.RETRIEVE Doctor Details\n5.Main menu");
						
							patChoice=sc.nextInt();
						switch(patChoice)
						{
						case 1:
						{
							System.out.println("Enter the number of doctor to be added");
							int n=sc.nextInt();
							String details[]=new String[n];
							System.out.println("Enter doctor details in the below format");
						
		                	System.out.println("doctorName/doctorFee/specialization/availableDate/availableTime");
							for(int i=0;i<n;i++)
							{
								details[i]=sc.next();
								
							}
							DoctorService out=new DoctorService();
							boolean flag=out.addDoctorList(details);
							if(flag)
							{
								System.out.println("Doctor details added successfully");
							}
							break;							
					}
						case 2:
							int choice1=0;
							do {
								System.out.println("Enter the details to update details\n1.UPDATE Available Date\n2.EXIT");
								choice1=sc.nextInt();
								switch(choice1)
								{
								case 1:
								{
									System.out.println("Enter the doctor Id");
									String doctorId=sc.next();
									System.out.println("Enter the Available Date");
									  String availableDate=sc.next();
									DoctorService out1=new DoctorService();
									boolean b=out1.updateDoctorDetail(doctorId,availableDate);
									if(b)
									{
										System.out.println("Doctor Available date updated successfully");
									}
									}
								}
							}while(choice1<2);
							break;
								case 3:
								{ 
									int choice2=0;
								
									do {
										System.out.println("Enter the details to delete\n1.Delete doctor details\n2.EXIT");
										choice2=sc.nextInt();
									
										switch(choice2)
										{
										case 1:
										{
											
										
									System.out.println("Enter the doctor Id");
									String docId=sc.next();
									DoctorService out2=new DoctorService();
									boolean b1=out2.deleteDoctorDetail(docId);
									if(b1)
									{
										System.out.println(docId+" is deleted successfully");
									}
										
								}
							}
								
								}while(choice2<2);
								} break;	
						case 4:
								System.out.println("Enter the Doctor Id");
							String docId=sc.next();
							DoctorService out3=new DoctorService();
							
							System.out.println();
                          
							for(Doctor o:out3.retrieveDoctorDetail(docId)) {
								System.out.println("Doctor id: "+o.getDoctorId());
								System.out.println("Doctor Name: "+o.getDoctorName());
								System.out.println("Doctor Fee: "+o.getDoctorFee());
								System.out.println("Specialization: "+o.getSpecialization());
								System.out.println("AvailableDate: "+o.getAvailableDate());
								System.out.println("AvailableTime: "+o.getAvailableTime());
								
								
							}						

						}
					}while(patChoice<=4);break;
					
                case 4:
					
					do
					{
						System.out.println("1.ADD Appointment Details\n2.DELETE Appointment Details\n3.RETRIEVE Appointment Details\n4.Main menu");
						
							patChoice=sc.nextInt();
							AppointmentService out=new AppointmentService();
						switch(patChoice)
						{
						
						case 1:
						{  
							System.out.println("Enter the Appointment Id");
							String aId=sc.next();
							System.out.println("Enter the Patient Id");
							String id=sc.next();
							System.out.println("Enter the Prefered specialist");
							String specialist=sc.next();
							System.out.println("Enter the mode of appointment");
							String modeOfPay=sc.next();
					
							
							boolean flag=out.addAppointmentdatail(aId,id,specialist,modeOfPay);
							if(flag)
							{
								System.out.println("Appointment details added successfully");
							}
							break;							
					}
						
								case 2:
								{ 
									int choice2=0;
								
									do {
										System.out.println("Enter the details to delete\n1.Delete Appointment details\n2.EXIT");
										choice2=sc.nextInt();
									
										switch(choice2)
										{
										case 1:
										{
											
										
									System.out.println("Enter the patient Id");
									String patId=sc.next();
								
									boolean b1=out.deleteAppointmentdatail(patId);
									if(b1)
									{
										System.out.println(patId+" is deleted successfully");
									}
										
								}
							}
								
								}while(choice2<2);
								} break;	
						case 3:
								System.out.println("Enter the Patient Id");
							String patId=sc.next();
							
							
							System.out.println();
                          
							for(Appointment o:out.retrieveAppointmentdetail(patId)) {
								System.out.println("Appointment id: "+o.getAppointmentId());
								System.out.println("Patient id: "+o.getPatientId());
								System.out.println("Doctor id: "+o.getDoctorId());
								System.out.println("Doctor Name: "+o.getDoctorName());
								System.out.println("Specialization: "+o.getSpecialization());
								System.out.println("Appointment Date: "+o.getAppointmentDate());
								System.out.println("Appointment Time: "+o.getAppointmentTime());
								System.out.println("Mode Of Appointment: "+o.getModeOfAppointment());
								
								
							}						

						}
					}while(patChoice<=3);break;
					
               case 5:
					
					do
					{
						System.out.println("1.Generate Allocation Details\n2.DELETE Allocation Details\n3.RETRIEVE Allocation Details\n4.Main menu");
						
							patChoice=sc.nextInt();
						switch(patChoice)
						{
						case 1:
						{
							String str="";
							System.out.println("Enter the number of Allocatoin to be added");
							int n=sc.nextInt();
							String details[]=new String[n];
							System.out.println("Enter Allocatoin details in the below format");
						
		                	System.out.println("Patient Id:Room No:NoOfDaysAdmitted:AdmissionDate:DischargeDate");
							for(int i=0;i<n;i++)
							{
								details[i]=sc.next();
								AllocationManagement am1=new AllocationManagement();
								String[] arr=details[i].split(":");
						     str=details[i]+":"+am1.retieveinpatient(arr[0]);
							}
							
							
							AllocationService out=new AllocationService();
							boolean flag=out.addAllocationList(str);
							if(flag)
							{
								System.out.println("Allocation details added successfully");
							}
							break;							
					}
								case 2:
								{ 
									int choice2=0;
								
									do {
										System.out.println("Enter the details to delete\n1.Delete Allocation details\n2.EXIT");
										choice2=sc.nextInt();
									
										switch(choice2)
										{
										case 1:
										{
											
										
									System.out.println("Enter the patient Id");
									String patId=sc.next();
									AllocationService out2=new AllocationService();
									boolean b1=out2.deleteAllocationDetail(patId);
									if(b1)
									{
										System.out.println(patId+" is deleted successfully");
									}
										
								}
							}
								
								}while(choice2<2);
								} break;	
						case 3:
								System.out.println("Enter the patient Id");
							String patId=sc.next();
							AllocationService out3=new AllocationService();
							
							System.out.println();
                          
							for(Allocation o:out3.retrieveAllocationDetail(patId)) {
								System.out.println("patient id: "+o.getPatientId());
								System.out.println("RoomNumber: "+o.getRoomNumber());
								System.out.println("NoOfDaysAdmitted: "+o.getNoOfDaysAdmitted());
								System.out.println("AdmissionDate: "+o.getAdmissionDate());
								System.out.println("DischargeDate: "+o.getDischargeDate());
								System.out.println("Treatment: "+o.getTreatment());
								System.out.println("Room Type: "+o.getRoomType());
								System.out.println("Required Food: "+o.getWantFood());
							}						

						}
					}while(patChoice<=3);break;
               case 6:
					
					do
					{
						System.out.println("1.Generate Payment Details\n2.RETRIEVE Payment Details\n3.Main menu");
						
							patChoice=sc.nextInt();
						switch(patChoice)
						{
						case 1:
						{
							String str="";
							System.out.println("Enter the number of Payment to be added");
							int n=sc.nextInt();
							String details[]=new String[n];
							System.out.println("Enter Payment details in the below format");
						
		                	System.out.println("Patient Id:Patient Type:Payment Date:Mode Of Pay");
		                	PaymentService out=new PaymentService();
							for(int i=0;i<n;i++)
							{
								details[i]=sc.next();
								
							}
							
					
							
							boolean flag=out.addPaymentList(details);
							if(flag)
							{
								System.out.println("Payment details added successfully");
							}
							break;							
					}
							
						case 2:
								System.out.println("Enter the patient Id");
								String patId=sc.next();
								PaymentService out=new PaymentService();
							
								System.out.println();
                         
							for(Payment o:out.retrievePaymentDetail(patId)) {
								System.out.println("Payment Id: "+o.getPaymentId());
								System.out.println("Patient Id: "+o.getPatientId());
								System.out.println("Patient Name: "+o.getPatientName());
								System.out.println("Patient Type: "+o.getPatientType());
								System.out.println("Patient Date: "+o.getPaymentDate());
								System.out.println("Mode Of Payment: "+o.getModeOfPayment());
								System.out.println("Bill Amount: "+o.getBillAmount());
								
							}						

						}
					}while(patChoice<=2);break;
				
				}
				
			}while(choice<6);
		}
	}
}
			