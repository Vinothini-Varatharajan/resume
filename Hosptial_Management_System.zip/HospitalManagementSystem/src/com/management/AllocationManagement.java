package com.management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Allocation;

public class AllocationManagement {

	public int insertAllocationDetails(List<Allocation> AllocationDetails)  {
		// TODO Auto-generated method stub
		int noOfRecordsAdded=0;
		Connection con= null;
		try {
			
		
			
			con=DBConnectionManager.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into allocation values(?,?,?,?,?,?,?,?,?)");
			for(Allocation o: AllocationDetails)
			{
				ps.setString(1, o.getAllocationId());
				ps.setString(2, o.getPatientId());
				ps.setInt(3, o.getRoomNumber());
				ps.setInt(4,o.getNoOfDaysAdmitted());
				ps.setDate(5, o.getAdmissionDate());
				ps.setDate(6, o.getDischargeDate());
				ps.setString(7, o.getTreatment());
				ps.setString(8, o.getRoomType());
				ps.setString(9, o.getWantFood());
			
				
				
				noOfRecordsAdded=ps.executeUpdate();
			}	
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			
		
			}
		
		return noOfRecordsAdded;
		}
		
		

	
	public int deleteAllocationDetails(String id) {
		
		int noOfRecordsDeleted=0;
		Connection con= null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("delete from allocation where PATIENT_ID=?");
				
					ps.setString(1,id);
				   
					noOfRecordsDeleted=ps.executeUpdate();
		
		
	           

				}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return noOfRecordsDeleted;
	}
public List<Allocation> retieveAllocationDetails(String id) {
		
		 ArrayList<Allocation> list = new ArrayList<Allocation>();
		    Connection con = null;
		    ResultSet rs = null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("select * from allocation where PATIENT_ID=?");
				
					ps.setString(1,id);
				   
				   rs = ps.executeQuery();
		
					 while(rs.next()){
						 Allocation obj = new Allocation(rs.getString(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getDate(5),rs.getDate(6),
								 rs.getString(7),rs.getString(8),rs.getString(9));
				            
				            list.add(obj);
	           

				}
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return list;
	}
public String retieveinpatient(String id) {
	
	 Connection con = null;
	    ResultSet rs = null;
	    String s="";

		
		try {
			
			con=DBConnectionManager.getConnection();
			PreparedStatement ps=con.prepareStatement("select TREATMENT,ROOM_TYPE,WANT_FOOD from inpatient where PATIENT_ID=?");
			
				ps.setString(1,id);
			   
			   rs = ps.executeQuery();
	
				 while(rs.next()){
				//	 Allocation obj = new Allocation(rs.getString(1),rs.getString(2),rs.getString(3));
			           
					   s=rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3);
			          

			}
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return s;
}
 
		
}

