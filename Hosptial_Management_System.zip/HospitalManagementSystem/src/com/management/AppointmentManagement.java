package com.management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Appointment;

public class AppointmentManagement {

	
	public int insertAppointmentDetail(List<Appointment> detail) {
		 
		 Connection con=null;
		 int noOfRecord=0;
		// Appointment o;
		 
			 try {
		 con=DBConnectionManager.getConnection();
		 PreparedStatement ps=con.prepareStatement("insert into appointment values(?,?,?,?,?,?,?,?)");
		 
		for(Appointment o: detail) {
		 ps.setString(1,o.getAppointmentId());
		 ps.setString(2,o.getPatientId());
		 ps.setString(3,o.getDoctorId());
		 ps.setString(4,o.getDoctorName());
		 ps.setString(5,o.getSpecialization());
		 ps.setDate(6,o.getAppointmentDate());
		 ps.setString(7,o.getAppointmentTime());
		 ps.setString(8,o.getModeOfAppointment());
		 

		 noOfRecord=ps.executeUpdate();
		}
		 }catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}finally {
				try 
				{
					con.close();
				}
				catch(Exception e)
				{}
			
				}
		 
		 return noOfRecord;
		 
	 }
	
	
	public String retrieveDocDetail(String specialist) {
		// TODO Auto-generated method stub
		 Connection con = null;
		    ResultSet rs = null;
		    String s="";

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("select DOCTOR_ID,DOCTOR_NAME,SPECIALIZATION,AVAILABLE_DATE,AVAILABLE_TIME from doctor where SPECIALIZATION=?");
				
					ps.setString(1,specialist);
				   
				   rs = ps.executeQuery();
		
					 while(rs.next()){
					
				           
						   s=rs.getString(1)+"/"+rs.getString(2)+"/"+rs.getString(3)+"/"+rs.getString(4)+"/"+rs.getString(5);
				          

				}
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return s;
	}
	

	public int deleteAppointmentDetails(String id) {
		
		int noOfRecordsDeleted=0;
		Connection con= null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("delete from appointment where PATIENT_ID=?");
				
					ps.setString(1,id);
				   
					noOfRecordsDeleted=ps.executeUpdate();
		
		
	           

				}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return noOfRecordsDeleted;
	}
	
	public List<Appointment> retieveAppointmentDetails(String id) {
		
		 ArrayList<Appointment> list = new ArrayList<Appointment>();
		    Connection con = null;
		    ResultSet rs = null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("select * from appointment where PATIENT_ID=?");
				
					ps.setString(1,id);
				   
				   rs = ps.executeQuery();
		
					 while(rs.next()){
						 Appointment obj = new Appointment(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getDate(6),
								 rs.getString(7),rs.getString(8));
				            
				            list.add(obj);
	           

				}
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return list;
	}	
	
			
	}

