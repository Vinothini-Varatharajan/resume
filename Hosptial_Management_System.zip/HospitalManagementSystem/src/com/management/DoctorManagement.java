package com.management;

import java.sql.Connection;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Doctor;

public class DoctorManagement {
	public int insertDoctorDetails(List<Doctor> DoctorDetails) {
		// TODO Auto-generated method stub
		int noOfRecordsAdded=0;
		Connection con= null;
		try {
			
			con=DBConnectionManager.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into doctor values(?,?,?,?,?,?)");
			for(Doctor o:DoctorDetails)
			{
				
				ps.setString(1, o.getDoctorId());
				ps.setString(2, o.getDoctorName());
				ps.setDouble(3, o.getDoctorFee());
				ps.setString(4,o.getSpecialization());
				ps.setDate(5, o.getAvailableDate());
				ps.setString(6, o.getAvailableTime());
				
//				Date date=Date.valueOf(o.getAvailableDate());
//				ps.setDate(5,date);
//				Time time=Time.valueOf( o.getAvailableTime());
//				ps.setTime(6,time);
//				
				noOfRecordsAdded=ps.executeUpdate();
			}	
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			try 
			{
				con.close();
			}
			catch(Exception e)
			{}
		
			}
		return noOfRecordsAdded;
		}

	public int updateDoctorDetails(String id,String date) {

		int noOfRecordsUpdated = 0;
		Connection con = null;

		try {

			con = DBConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement("update doctor set AVAILABLE_DATE=? where DOCTOR_ID=?");

			ps.setString(1, date);
			ps.setString(2, id);

			noOfRecordsUpdated = ps.executeUpdate();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return noOfRecordsUpdated;
	}

	public int deleteDoctorDetails(String id) {

		int noOfRecordsDeleted = 0;
		Connection con = null;

		try {

			con = DBConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement("delete from doctor where DOCTOR_ID=?");

			ps.setString(1, id);

			noOfRecordsDeleted = ps.executeUpdate();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return noOfRecordsDeleted;
	}

	public List<Doctor> retieveDoctorDetails(String id) {

		ArrayList<Doctor> list = new ArrayList<Doctor>();
		Connection con = null;
		ResultSet rs = null;

		try {

			con = DBConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from doctor where DOCTOR_ID=?");

			ps.setString(1, id);

			rs = ps.executeQuery();

			while (rs.next()) {
				Doctor obj = new Doctor(rs.getString(1), rs.getString(2), rs.getDouble(3), rs.getString(4),
						rs.getDate(5),rs.getString(6));

				list.add(obj);

			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

}
