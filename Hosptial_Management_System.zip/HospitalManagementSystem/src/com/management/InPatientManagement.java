package com.management;

import java.sql.Connection;
import java.sql.ResultSet;

import java.sql.PreparedStatement;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.InPatient;

public class InPatientManagement {

	public int insertInPatientDetails(List<InPatient> InPatientDetails) {
		// TODO Auto-generated method stub
		int noOfRecordsAdded=0;
		Connection con= null;
		try {
			
			
			
			
			con=DBConnectionManager.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into inpatient values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
			for(InPatient o: InPatientDetails)
			{
				ps.setString(1, o.getPatientId());
				ps.setString(2, o.getPatientName());
				ps.setLong(3, o.getPhoneNumber());
				ps.setInt(4,o.getAge());
				ps.setString(5, o.getGender());
				ps.setString(6, o.getMedicalHistory());
				ps.setString(7, o.getPrefferedSpecialist());
				ps.setDouble(8, o.getMedicineFee());
				ps.setString(9, o.getPatientType());
				ps.setDouble(10,o.getAdmissionFees());
				ps.setString(11,o.getTreatment());
				ps.setString(12,o.getRoomType());
				ps.setString(13,o.getWantFood());
				
				
				noOfRecordsAdded=ps.executeUpdate();
			}	
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			try 
			{
				con.close();
			}
			catch(Exception e)
			{}
		
			}
		return noOfRecordsAdded;
		}
		
		

	public int updateInPatientDetails(String id,long phNo) {
		
		int noOfRecordsUpdated=0;
		Connection con= null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("update inpatient set PHONE_NUMBER=? where PATIENT_ID=?");
				
					
					ps.setLong(1, phNo);
					ps.setString(2,id);
					
					noOfRecordsUpdated=ps.executeUpdate();
		
		
	           

				}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return noOfRecordsUpdated;
	}

	public int deleteInPatientDetails(String id) {
		
		int noOfRecordsDeleted=0;
		Connection con= null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("delete from inpatient where PATIENT_ID=?");
				
					ps.setString(1,id);
				   
					noOfRecordsDeleted=ps.executeUpdate();
		
		
	           

				}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return noOfRecordsDeleted;
	}
public List<InPatient> retieveInPatientDetails(String id) {
		
		 ArrayList<InPatient> list = new ArrayList<InPatient>();
		    Connection con = null;
		    ResultSet rs = null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("select * from inpatient where PATIENT_ID=?");
				
					ps.setString(1,id);
				   
				   rs = ps.executeQuery();
		
					 while(rs.next()){
						 InPatient obj = new InPatient(
rs.getString(1),rs.getString(2),rs.getLong(3),rs.getInt(4),rs.getString(5),rs.getString(6),
rs.getString(7),rs.getDouble(8),rs.getString(9),rs.getDouble(10),rs.getString(11),rs.getString(12),rs.getString(13));
				            
				            list.add(obj);
	           

				}
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return list;
	}

		
		
}

