package com.management;

import java.sql.Connection;
import java.sql.ResultSet;

import java.sql.PreparedStatement;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.OutPatient;

public class OutPatientManagement {

	public int insertOutPatientDetails(List<OutPatient> OutPatientDetails) {
		// TODO Auto-generated method stub
		int noOfRecordsAdded=0;
		Connection con= null;
		try {
			
			con=DBConnectionManager.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into outpatient values(?,?,?,?,?,?,?,?,?,?)");
			for(OutPatient o:OutPatientDetails)
			{
				ps.setString(1, o.getPatientId());
				ps.setString(2, o.getPatientName());
				ps.setLong(3, o.getPhoneNumber());
				ps.setInt(4,o.getAge());
				ps.setString(5, o.getGender());
				ps.setString(6, o.getMedicalHistory());
				ps.setString(7, o.getPrefferedSpecialist());
				ps.setDouble(8, o.getMedicineFee());
				ps.setString(9, o.getPatientType());
				ps.setDouble(10,o.getRegistrationFees());
					
				noOfRecordsAdded=ps.executeUpdate();
			}	
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			try 
			{
				con.close();
			}
			catch(Exception e)
			{}
		
			}
		return noOfRecordsAdded;
		}
		
		

	public int updateOutPatientDetails(String id,long phNo) {
		
		int noOfRecordsUpdated=0;
		Connection con= null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("update outpatient set PHONE_NUMBER=? where PATIENT_ID=?");
				
					
					ps.setLong(1, phNo);
					ps.setString(2,id);
					
					noOfRecordsUpdated=ps.executeUpdate();
		
		
	           

				}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return noOfRecordsUpdated;
	}

	public int deleteOutPatientDetails(String id) {
		
		int noOfRecordsDeleted=0;
		Connection con= null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("delete from outpatient where PATIENT_ID=?");
				
					ps.setString(1,id);
				   
					noOfRecordsDeleted=ps.executeUpdate();
		
		
	           

				}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return noOfRecordsDeleted;
	}
public List<OutPatient> retieveOutPatientDetails(String id) {
		
		 ArrayList<OutPatient> list = new ArrayList<OutPatient>();
		    Connection con = null;
		    ResultSet rs = null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("select * from outpatient where PATIENT_ID=?");
				
					ps.setString(1,id);
				   
				   rs = ps.executeQuery();
		
					 while(rs.next()){
 OutPatient obj = new OutPatient(
rs.getString(1),rs.getString(2),rs.getLong(3),rs.getInt(4),rs.getString(5),rs.getString(6),
rs.getString(7),rs.getDouble(8),rs.getString(9),rs.getDouble(10));
				            
				            list.add(obj);
	           

				}
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return list;
	}

		
		
}

