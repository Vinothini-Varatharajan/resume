package com.management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Payment;

public class PaymentManagement {

	public int insertPaymentDetails(List<Payment> PaymentDetails) {
		// TODO Auto-generated method stub
		int noOfRecordsAdded=0;
		Connection con= null;
		try {
			
			
			
//			(String paymentId, String patientId, String patientName, String patientType, String paymentDate,
//					String modeOfPayment, double billAmount) 
			
			con=DBConnectionManager.getConnection();
			

			
			
			PreparedStatement ps=con.prepareStatement("insert into payment values(?,?,?,?,?,?,?)");
			for(Payment o: PaymentDetails)
			{
				ps.setString(1, o.getPaymentId());
				ps.setString(2, o.getPatientId());
				ps.setString(3, o.getPatientName());
				ps.setString(4,o.getPatientType());
				ps.setDate(5,o.getPaymentDate());
				ps.setString(6, o.getModeOfPayment());
				ps.setDouble(7, o.getBillAmount());
				
				
				
				noOfRecordsAdded=ps.executeUpdate();
			}	
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			try 
			{
				con.close();
			}
			catch(Exception e)
			{}
		
			}
		return noOfRecordsAdded;
		}
		
	
public ArrayList<Payment> retievePaymentDetails(String id) {
		
		 ArrayList<Payment> list = new ArrayList<Payment>();
		    Connection con = null;
		    ResultSet rs = null;
		

			
			try {
				
				con=DBConnectionManager.getConnection();
				PreparedStatement ps=con.prepareStatement("select * from payment where PATIENT_ID=?");
				
					ps.setString(1,id);
				   
				   rs = ps.executeQuery();
		
					 while(rs.next()){
						 Payment obj = new Payment(
rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDate(5),rs.getString(6),
rs.getDouble(7));
				            
				            list.add(obj);
	           

				}
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			return list;
	}

		
public String retieveNameAndAmount(String id) {
	
	 Connection con = null;
	    ResultSet rs = null;
	    String s="";

		
		try {
			
			con=DBConnectionManager.getConnection();
			PreparedStatement ps=con.prepareStatement("select PATIENT_NAME,	MEDICINE_FEE,ADMISSION_FEES from inpatient where PATIENT_ID=?");
			
				ps.setString(1,id);
			   
			   rs = ps.executeQuery();
	
				 while(rs.next()){

			           
					   s=rs.getString(1)+":"+(rs.getDouble(2)+rs.getDouble(3));
			          

			}
				 
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return s;
}

		
		
}


