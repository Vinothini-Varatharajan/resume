package com.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.management.AllocationManagement;
import com.model.Allocation;
import com.util.ApplicationUtil;

public class AllocationService {

public List<Allocation> buildAllocationList(List<String> AllocationDetails){
		
		List<Allocation> AllocationDetailList = new ArrayList<Allocation>();
	     
//   AllocationManagement am=new AllocationManagement();
//		
//   AllocationDetailList.addAll(am.retieveinpatient("INhe")); 
		
  

		for(String i:AllocationDetails) {
			String arr[]= i.split(":");
			Allocation ob=new Allocation(arr[0],arr[1],Integer.parseInt(arr[2]),Integer.parseInt(arr[3]),ApplicationUtil.utilToSqlDateConverter(ApplicationUtil.stringToDateConverter(arr[4])),
					ApplicationUtil.utilToSqlDateConverter(ApplicationUtil.stringToDateConverter(arr[5])),arr[6],arr[7],arr[8]);
			
			AllocationDetailList.add(ob);	
			}
		
		  return AllocationDetailList;
		}
     AllocationManagement obj= new AllocationManagement();
	public boolean addAllocationList(String...  AllocationDetails) {
		// TODO Auto-generated method stub
		int result=obj.insertAllocationDetails(buildAllocationList(ApplicationUtil.extractAllocationDetails(AllocationDetails)));
    	if(result<=0) {
    		return false;
    	}else {
    		return true;
    	}
		//return false;
	}

	public boolean deleteAllocationDetail(String patientId2) {
		// TODO Auto-generated method stub
		int result= obj.deleteAllocationDetails(patientId2);
    	
    	if(result<=0) 
    	{
    		return false;
    	}
    	else 
    	{
    		return true;
    	}
    	
   
	}
	public List<Allocation> retrieveAllocationDetail(String patientId) {
		// TODO Auto-generated method stub
		  
	   
	return obj.retieveAllocationDetails(patientId);
	}
//	public List<Allocation>  inpatientList(String patientId) {
//	
//          
//
}
