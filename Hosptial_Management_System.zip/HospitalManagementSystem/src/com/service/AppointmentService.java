package com.service;

import java.util.ArrayList;
import java.util.List;

import com.management.AppointmentManagement;
import com.model.Appointment;
import com.util.ApplicationUtil;

public class AppointmentService {

	
	public List<Appointment> buildAppointmentList(String string) {
		// TODO Auto-generated method stub
		List<Appointment> list=new ArrayList <Appointment>();
		
		String arr[]=string.split("/");
		
		Appointment obj=new Appointment(arr[0],arr[1],arr[2],arr[3],arr[4],
				ApplicationUtil.utilToSqlDateConverter(ApplicationUtil.stringToDateConverter(arr[5])),arr[6],arr[7]);
		 list.add(obj);
		return list;
		
		
	}	
  AppointmentManagement obj=new AppointmentManagement();
public boolean addAppointmentdatail(String aId,String id,String specialist,String mode) {

   
	int result=obj.insertAppointmentDetail(buildAppointmentList(ApplicationUtil.extractAppoinmentDetails(aId,id,specialist,mode)));

	if(result>0) {
		return true;
	}else {
	return false;
	}
}


public boolean deleteAppointmentdatail(String patientId) {
	
	
	int result=obj.deleteAppointmentDetails(patientId);
	
	if(result>0){
	   return true;
	}else{
		return false;
	}
}
public List<Appointment> retrieveAppointmentdetail(String patientId) {



return obj.retieveAppointmentDetails(patientId);

} 
	
}
