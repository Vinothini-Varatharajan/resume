package com.service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.management.DoctorManagement;
import com.model.Doctor;
import com.util.ApplicationUtil;

public class DoctorService {
public List<Doctor> buildDoctorList(List<String> DoctorDetails){
		
		List<Doctor> DoctorDetailList = new ArrayList<Doctor>();
		
		for(String i:DoctorDetails) {
			String arr[]= i.split("/");
			
			Doctor doc=new Doctor(arr[0],arr[1],Double.parseDouble(arr[2]),arr[3],utilToSqlDateConverter(stringToDateConverter(arr[4])),
					arr[5]);
			DoctorDetailList.add(doc);	
			}
		
		  return DoctorDetailList;
		}
public static java.util.Date stringToDateConverter(String stringDate) {
	
	java.util.Date date = null;
	SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",java.util.Locale.getDefault());
	try
	{
	if(stringDate!=null)
		{return df.parse(stringDate);}
	}catch(ParseException e) {}
	return date;
	
}

public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
	
	java.sql.Date sqlDate = null;
	if(utDate!=null)
	{
		sqlDate=new java.sql.Date(utDate.getTime());
	}
	return sqlDate;
}

public static java.util.Date sqlToUtilDateConverter(java.sql.Date sDate) {
    
    java.util.Date utDate = null;
		if (sDate != null) {
			utDate = new java.util.Date(sDate.getTime());
		}
		return utDate;
}





DoctorManagement obj= new DoctorManagement();
	public boolean addDoctorList(String... DoctorDetails) {
		// TODO Auto-generated method stub
		int result = obj.insertDoctorDetails(buildDoctorList(ApplicationUtil.extractDoctorDetails(DoctorDetails))); 
    	if(result<=0) {
    		return false;
    	}else {
    		return true;
    	}
		//return false;
	}
	public boolean updateDoctorDetail(String docId,String date) {
		// TODO Auto-generated method stub
		int result = obj.updateDoctorDetails(docId,date);
    	if(result<=0) {
    		return false;
    	}else {
    		return true;
    	}
    	
		
	}
	public boolean deleteDoctorDetail(String patientId2) {
		// TODO Auto-generated method stub
		int result= obj.deleteDoctorDetails(patientId2);
    	
    	if(result<=0) 
    	{
    		return false;
    	}
    	else 
    	{
    		return true;
    	}
    	
   
	}
	public List<Doctor> retrieveDoctorDetail(String patientId) {
		// TODO Auto-generated method stub
		  
	   
	return obj.retieveDoctorDetails(patientId);
	}

}
