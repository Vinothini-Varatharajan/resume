package com.service;

import java.util.ArrayList;
import java.util.List;

import com.management.InPatientManagement;
import com.model.InPatient;
import com.util.ApplicationUtil;


public class InPatientService {
	
public List<InPatient> buildInPatientList(List<String> InPatientDetails){
		
		List<InPatient> InPatientDetailList = new ArrayList<InPatient>();

		for(String i:InPatientDetails) {
			String arr[]= i.split(":");
			InPatient ob=new InPatient(arr[0],arr[1],Long.parseLong(arr[2]),Integer.parseInt(arr[3]),arr[4],arr[5],
					arr[6],Double.parseDouble(arr[7]),arr[8],Double.parseDouble(arr[9]),arr[10],arr[11],arr[12]);
			
			InPatientDetailList.add(ob);	
			}
		
		  return InPatientDetailList;
		}
     InPatientManagement obj= new InPatientManagement();
	public boolean addInPatientList(String... InPatientDetails) {
		// TODO Auto-generated method stub
		int result=obj.insertInPatientDetails(buildInPatientList(ApplicationUtil.extractInPatientDetails(InPatientDetails)));
	//	int result = obj.insertInPatientDetails(buildInPatientList(ApplicationUtil.extractInPatientDetails(InPatientDetails))); 
    	if(result<=0) {
    		return false;
    	}else {
    		return true;
    	}
		//return false;
	}
	public boolean updateInPatientPhoneNumber(String patientId2, long phoneNumber2) {
		// TODO Auto-generated method stub
		int result = obj.updateInPatientDetails(patientId2,phoneNumber2);
    	if(result<=0) {
    		return false;
    	}else {
    		return true;
    	}
    	
		
	}
	public boolean deleteInPatientDetail(String patientId2) {
		// TODO Auto-generated method stub
		int result= obj.deleteInPatientDetails(patientId2);
    	
    	if(result<=0) 
    	{
    		return false;
    	}
    	else 
    	{
    		return true;
    	}
    	
   
	}
	public List<InPatient> retrieveInPatientDetail(String patientId) {
		// TODO Auto-generated method stub
		  
	   
	return obj.retieveInPatientDetails(patientId);
	}



}
