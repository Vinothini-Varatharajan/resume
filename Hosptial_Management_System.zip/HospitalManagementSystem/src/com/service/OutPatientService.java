package com.service;

import java.util.ArrayList;
import java.util.List;

import com.management.OutPatientManagement;
import com.model.OutPatient;
import com.util.ApplicationUtil;

public class OutPatientService {
	
	
	public List<OutPatient> buildOutPatientList(List<String> OutPatientDetails){
		
		List<OutPatient> OutPatientDetailList = new ArrayList<OutPatient>();
		
		for(String i:OutPatientDetails) {
			String arr[]= i.split(":");
			OutPatient outp=new OutPatient(arr[0],arr[1],Long.parseLong(arr[2]),Integer.parseInt(arr[3]),arr[4],arr[5],
					arr[6],Double.parseDouble(arr[7]),arr[8],Double.parseDouble(arr[9]));
			OutPatientDetailList.add(outp);	
			}
		
		  return OutPatientDetailList;
		}
	OutPatientManagement obj= new OutPatientManagement();
	public boolean addOutPatientList(String... OutPatientDetails) {
		// TODO Auto-generated method stub
		int result = obj.insertOutPatientDetails(buildOutPatientList(ApplicationUtil.extractOutPatientDetails(OutPatientDetails))); 
    	if(result<=0) {
    		return false;
    	}else {
    		return true;
    	}
		//return false;
	}
	public boolean updateOutPatientPhoneNumber(String patientId2, long phoneNumber2) {
		// TODO Auto-generated method stub
		int result = obj.updateOutPatientDetails(patientId2,phoneNumber2);
    	if(result<=0) {
    		return false;
    	}else {
    		return true;
    	}
    	
		
	}
	public boolean deleteOutPatientDetail(String patientId2) {
		// TODO Auto-generated method stub
		int result= obj.deleteOutPatientDetails(patientId2);
    	
    	if(result<=0) 
    	{
    		return false;
    	}
    	else 
    	{
    		return true;
    	}
    	
   
	}
	public List<OutPatient> retrieveOutPatientDetail(String patientId) {
		// TODO Auto-generated method stub
		  
	   
	return obj.retieveOutPatientDetails(patientId);
	}

}
