package com.service;

import java.util.ArrayList;
import java.util.List;
import com.management.PaymentManagement;
import com.model.Payment;
import com.util.ApplicationUtil;

public class PaymentService {
   

	
	
	
public List<Payment> buildPaymentList(List<String> PaymentDetails){
		
		List<Payment> PaymentDetailList = new ArrayList<Payment>();
		
		for(String i:PaymentDetails) {
			String arr[]= i.split(":");
			
			Payment doc=new Payment(arr[0],arr[1],arr[2],arr[3],ApplicationUtil.utilToSqlDateConverter(ApplicationUtil.stringToDateConverter(arr[4])),
					arr[5],Double.parseDouble(arr[6]));
			PaymentDetailList.add(doc);	
			}
		
		  return PaymentDetailList;
		}


     PaymentManagement obj= new PaymentManagement();
	public boolean addPaymentList(String... PaymentDetails) {
		// TODO Auto-generated method stub
		//System.out.println(PaymentDetails[0]);
		int result = obj.insertPaymentDetails(buildPaymentList(ApplicationUtil.extractPaymentDetails(PaymentDetails))); 
    	if(result<=0) {
    		return false;
    	}else {
    		return true;
    	}
		//return false;
	}
	
	
	public List<Payment> retrievePaymentDetail(String patientId) {
		// TODO Auto-generated method stub
		  
	   
	return obj.retievePaymentDetails(patientId);
	}
	
	public static String getName(String id) {
		if(id.startsWith("IN")) {
			System.out.println("inpatient");
		}else if(id.startsWith("OUT")) {
			System.out.println("OUTpatient");
		}
		
		return null;
		
	}
}

