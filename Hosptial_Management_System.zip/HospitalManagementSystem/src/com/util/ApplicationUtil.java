package com.util;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.management.AppointmentManagement;
import com.management.PaymentManagement;

public class ApplicationUtil {
	
	  static int num1=0,num2=0,num3=0,num4=0,num5=0,num6=0;
	  
	

	  


public static List <String> extractOutPatientDetails(String... pDetails) {
	    num1++;
		List <String> pd=new ArrayList <String>();
		
		String id="";
		String pdArray[];
		for(String details:pDetails)
		{
		pdArray=details.split(":"); 
		for(int i=0; i<pdArray.length;i++)
		{
		
	//	id=generateOutPatientId();
			id="OUTPAT"+num1;
			
		}
		for(int i=0;i<pdArray.length;i++)
		{
			id=id+":"+pdArray[i];
		}
		
		pd.add(id);
		
		
		
		}
		
		return pd;	
			
		}
	
/* public static String generateOutPatientId() {
		
	String key="OUTPAT";
	
	key=key+(outnum1);
	outnum1++;
		return key;
	}
*/
	
public static List<String> extractInPatientDetails(String[] pDetails) {
	num2++;
	List <String> pd=new ArrayList<String>();
	
	String id="";
	String pdArray[];
	for(String details:pDetails)
	{
	pdArray=details.split(":"); 
	for(int i=0; i<pdArray.length;i++)
	{
	
		id="INPAT"+num2;
	}
	for(int i=0;i<pdArray.length;i++)
	{
		id=id+":"+pdArray[i];
	}
	
	pd.add(id);

	}
	
	return pd;	

}
/*
public static String generateInPatientId() {
	
	String key="INPAT";
	
	key=key+(100+num2);
	
	
		return key;
	}
*/


public static List<String> extractDoctorDetails(String[] pDetails) {

	num3++;
	List <String> pd=new ArrayList <String>();
	
	String id="";
	String pdArray[];
	for(String details:pDetails)
	{
	pdArray=details.split("/"); 
	for(int i=0; i<pdArray.length;i++)
	{
	
	id="DOC"+num3;

	}
	for(int i=0;i<pdArray.length;i++)
	{
		id=id+"/"+pdArray[i];
	}
	
	pd.add(id);
	
	
	
	}
	
	return pd;	
		
	}

/*public static String generateDoctorId() {
	num3++;
String key="DOC";


key=key+(100+num3);

	return key;
}
*/
public static List<String> extractAllocationDetails(String[] pDetails) {

	
	List <String> pd=new ArrayList <String>();
	
	num4++;
	
	String id="";
	String pdArray[];
	for(String details:pDetails)
	{
	pdArray=details.split(":"); 
	//for(int i=0; i<pdArray.length;i++)
	//{
	
	id="ALLOCAT"+num4;

//	}
	for(int i=0;i<pdArray.length;i++)
	{
		id=id+":"+pdArray[i];
	}
	pd.add(id);
	
	
	
	}
	
	return pd;	
		
	}
/*
public static String generateAllocationId() {
	num4++;
String key="ALLOCAT";


key=key+(100+num4);

	return key;
}
*/
public static List<String> extractPaymentDetails(String[] pDetails) {

	
	 
	
	List <String> pd=new ArrayList <String>();
	PaymentManagement am=new PaymentManagement();
	
	
	 
	num5++;
	String id="";String id1="";
	String pdArray[];
	String nameArray[];
	for(String details:pDetails)
	{
	pdArray=details.split(":");
	
	
	String name=am.retieveNameAndAmount(pdArray[0]);
	nameArray=name.split(":");



	id="PAYID"+num5;
	
  
	
//	for(int i=0;i<pdArray.length;i++)
//	{
		
		id1=id+":"+pdArray[0]+":"+nameArray[0]+":"+pdArray[1]+":"+pdArray[2]+":"+pdArray[3]+":"+nameArray[1];
	//}
	pd.add(id1);
	
	
	
	}
	
	return pd;	
		
	}

/*public static String generatePaymentId() {
	num5++;
String key="PAYID";


key=key+(100+num5);

	return key;
} */
public static String extractAppoinmentDetails(String id1,String id,String specialist,String mode) {
	// TODO Auto-generated method stub
	//List <String> pd=new ArrayList <String>();
	
	AppointmentManagement am=new AppointmentManagement();
	
	
	String str=am.retrieveDocDetail(specialist);
	
	
	
	String detail=id1+"/"+id+"/"+str+"/"+mode;
	
	return detail;
} 
/*public static String generateAppointmentId() {

String key="APPOINT";

num6++;

key=key+(100+num6);

	return key;
}
*/



public static java.util.Date stringToDateConverter(String stringDate) {
	
	java.util.Date date = null;
	SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",java.util.Locale.getDefault());
	try
	{
	if(stringDate!=null)
		{return df.parse(stringDate);}
	}catch(ParseException e) {}
	return date;
	
}

public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
	
	java.sql.Date sqlDate = null;
	if(utDate!=null)
	{
		sqlDate=new java.sql.Date(utDate.getTime());
	}
	return sqlDate;
}

public static java.util.Date sqlToUtilDateConverter(java.sql.Date sDate) {
    
    java.util.Date utDate = null;
		if (sDate != null) {
			utDate = new java.util.Date(sDate.getTime());
		}
		return utDate;
}






	
}
